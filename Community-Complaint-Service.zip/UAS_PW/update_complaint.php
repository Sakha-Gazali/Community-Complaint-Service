<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $subject = $conn->real_escape_string($_POST['subject']);
    $message = $conn->real_escape_string($_POST['message']);

    $sql = "UPDATE complaints SET name='$name', email='$email', subject='$subject', message='$message' WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        // Redirect to complaints.php after successful update
        header("Location: complaints.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }    
}

$conn->close();
?>
