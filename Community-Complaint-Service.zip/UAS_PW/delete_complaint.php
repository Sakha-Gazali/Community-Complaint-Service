<?php
include 'db_connect.php';

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $sql = "DELETE FROM complaints WHERE id=$id";

  if ($conn->query($sql) === TRUE) {
    echo "Complaint deleted successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();
  header("Location: complaints.php");
}
?>
